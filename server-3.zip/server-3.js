/*
 * City Life Online - server-3.js
 *
 * SAFE COMPATIBILITY STARTER
 * --------------------------
 * This file starts your existing server-2.js without replacing its game code.
 * That preserves the game features currently implemented in server-2.js.
 *
 * Important: this starter does NOT yet add the requested larger map/interiors.
 * Those changes need to be integrated with the actual game code so they do
 * not break multiplayer, cars, money, chat, or house buying.
 *
 * To use this file on Render, set the Start Command to:
 *   node server-3.js
 */

'use strict';

const fs = require('fs');
const path = require('path');

const existingServer = path.join(__dirname, 'server-2.js');

if (!fs.existsSync(existingServer)) {
  console.error('City Life Online: server-2.js was not found.');
  console.error('Upload server-2.js alongside server-3.js in your GitHub repository.');
  process.exit(1);
}

console.log('City Life Online: starting existing server-2.js to preserve current game features.');

try {
  require(existingServer);
} catch (error) {
  console.error('City Life Online could not start server-2.js:', error);
  process.exit(1);
}
